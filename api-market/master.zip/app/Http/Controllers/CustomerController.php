<?php

namespace App\Http\Controllers;

use App\Helpers\Boedysoft;
use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class CustomerController extends Controller
{
    public function index()
    {
        $cari = \request('cari');
        $limit = \request('limit');
        $data = Customer::query();
        if ($cari) $data->where(function ($q) use ($cari) {
            $q->where('nama', 'like', "%$cari%");
            $q->orWhere('alamat', 'like', "%$cari%");
            $q->orWhere('telpon', 'like', "%$cari%");
            $q->orWhere('email', 'like', "%$cari%");
        });
        $data->whereHas('perusahaan',function ($q){
            $q->where('owner_id',\request()->user()->perusahaan->owner->id);
        });
        $data->orderByDesc('id');
        if ($limit) {
            return Boedysoft::getJson(200, '', $data->skip(0)->take($limit)->get());
        } else {
            return Boedysoft::getJson(200, '', $data->get());
        }
    }

    public function store(Request $request)
    {
        $valid = Validator::make($request->all(), [
            'nama' => 'required|min:5',
            'alamat' => 'required',
            'email' => 'required|email',
            'telpon' => 'required',
        ]);
        if ($valid->fails()) {
            return Boedysoft::getJson(201, 'Maaf form tidak falid..!', $valid->errors());
        } else {
            $form = $request->all();
            if (gettype($request->photo) != 'string') $form['photo'] = Boedysoft::copyStorage('customer', $request->photo);
            if ($request->id) {
                $data = Customer::find($request->id);
                $data->update(array_merge($form, [
                    'user_id' => $request->user()->id,
                    'perusahaan_id' => $request->user()->perusahaan_id,
                ]));
                return Boedysoft::getJson(200, 'Sukses Edit data customer..!',$data);
            } else {
                $data = Customer::create(array_merge($form, [
                    'user_id' => $request->user()->id,
                    'perusahaan_id' => $request->user()->perusahaan_id,
                ]));
                return Boedysoft::getJson(200, 'Sukses membuat data customer..!',$data);
            }
        }
    }

    public function show(Customer $customer)
    {
        return Boedysoft::getJson(200, null, $customer);
    }

    public function destroy(Customer $customer)
    {
        $customer->delete();
        return Boedysoft::getJson(200, 'Sukses menghapus data..!');
    }
}
