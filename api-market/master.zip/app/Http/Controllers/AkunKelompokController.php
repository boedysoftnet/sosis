<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AkunKelompokController extends Controller
{
    //
}
