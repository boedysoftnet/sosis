<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class KonfigruasiController extends Controller
{
    //
}
